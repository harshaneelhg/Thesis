function kp = Kmore_Prob(pV,k,flag)

%compute k-more prob: at least k events will occur;
if nargin<3
    flag = 1;
end
if nargin<2
    k = 0;
end
[m,n] = size(pV);

if flag==1
    if k==n
        kp = ones(m,1);
        for j=1:n
            kp = kp.*pV(:,j);
        end
    else
        kp = ones(m,n);
        for j=1:m
            for i=1:n
                kp(j,1:i+1) = [0 pV(j,i)*kp(j,1:i)]+[kp(j,1:i) 0];
            end
        end
        if k>0
            kp = kp(:,k+1);
        end
    end
else%by order statistic
    tmp = sort(pV,2);
    kp = tmp(:,end-k+1);
end
    

function nP = Addone(tP,p)

%tP is 1xlen, tP(i) denotes the prob at least (i-1) events will occue
%p is the prob of a new event

nP = [0 p*tP]+[tP 0];
